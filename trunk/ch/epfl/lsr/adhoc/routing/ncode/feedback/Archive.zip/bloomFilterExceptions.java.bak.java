package ch.epfl.lsr.adhoc.routing.ncode.feedback;

public class bloomFilterExceptions extends Exception {
	public bloomFilterExceptions(String string) {
		super(string);

	}

	public bloomFilterExceptions (String message, Throwable cause) {
		super(message,cause);
	}

	public bloomFilterExceptions(Throwable cause) {
		super(cause);
	}
}
