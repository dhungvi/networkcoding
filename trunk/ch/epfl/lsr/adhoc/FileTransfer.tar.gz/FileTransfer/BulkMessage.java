package ch.epfl.lsr.adhoc.FileTransfer;

import ch.epfl.lsr.adhoc.runtime.Message;

/**
 * This is a implementation of a bulk transfer message object.
 * <p>
 * This Message is a very simple implementation of Message, which allows to
 * set and get a bytearray. It is created through the BulkMessageFactory class
 * (also a simple test class).
 * <p>
 * @see BulkMessageFactory
 * @see Message
 * @author Kave Salamatian
 * @version 1.0
 */
public class BulkMessage extends Message {
  /** Contains the actual message */
  private byte[] payload;

  /**
   * Creates a new instance of BulkMessage.
   * <p>
   * The type of this message object is initialized at creation time and cannot
   * be changed later (for better use in a MessagePool).
   * <p>
   * @param type The type of service for this message
   */
  public BulkMessage(char type) {
    super(type);
  }

  /**
   * Write the bulk payload (for this message) with the addString() method to the
   * buffer (for sending the message on the network).
   */
  public void prepareData() {
    addBytes(payload);
  }

  /**
   * Read the payload (for this message) from the buffer with the getString() method.
   */
  public void readData() {
	byte[] Buf=new byte[10000];
    int len = getBytes(Buf);
    payload= new byte[len];
	System.arraycopy(Buf,0,payload,0,len);	  
  }

  /**
   * Changes the bulk payload in this message object.
   * <p>
   * @param buf The new payload
   */
  public void setText(byte[] buf) {
	    payload= new byte[buf.length];
		System.arraycopy(buf,0,payload,0,buf.length);	  
  }

  /**
   * Returns the payload contained whithin this message object.
   * <p>
   * @return The payload in this message object
   */
  public byte[] getText() {
    return payload;
  }

  /**
   * Overwrites Object.toString().
   * <p>
   * This method allows this message object to be printed in a statement such
   * as System.out.println().
   * <p>
   * @return A String representation of this object (the text containted in this message)
   */
  public String toString() {
    return payload.toString();
  }
}
