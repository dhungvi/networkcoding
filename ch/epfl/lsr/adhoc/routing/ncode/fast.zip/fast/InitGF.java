package ch.epfl.lsr.adhoc.routing.ncode.fast;

	/**
	 * InitGF initializes the GF Element to Exponent (FEtoExp) table
	 *  and the Exponent to Element (ExptoFE) tables. 
	 *
	 * SMultField is the size of field 
	 *                (2^{Lfield}-1) == TableLength - 1. 
	 * 
	 * pCOLBIT is a pointer to the COLBIT, which is used to 
	 *               make sure rows and columns have 
	 *               distinct field elements associated with them.
	 * The BIT array is used to mask out single bits in 
	 *               equations: bit 
	 * ExptoFE is the table that goes from the exponent to the 
	 *               finite field element. 
	 * FEtoExp == FEtoExp is the table that goes from the finite field 
	 *               element to the exponent. 
	 * Lfield is the log of the length of the field. 
	 *
	 * @author   Kav� Salamatian
	 * @version
	 **/
	public class InitGF
	{
	  public static int MAXLFIELD = 16;
	  public static int COLBIT[][];
	  public static int BIT[][];
	  public static int ExptoFE[][];
	  public static int FEtoExp[][];

	  static
	  {
	    generateTables(MAXLFIELD);
	  }

	  /**
	   * Retrieve the COLBIT table for the input Lfield.
	   *
	   * @param Lfield == the Lfield to retrieve a COLBIT table for. */
	  public static int[] getCOLBIT(int Lfield)
	  {
	    return COLBIT[Lfield];
	  }

	  /**
	   * Retreve the BIT table for the input Lfield.
	   *
	   * @param Lfield == the Lfield to retrieve a BIT table for. */
	  public static int[] getBIT(int Lfield)
	  {
	    return BIT[Lfield];
	  }

	  /**
	   * Retreve the ExptoFE table for the input Lfield.
	   *
	   * @param Lfield == the Lfield to retrieve a ExptoFE table for. */
	  public static int[] getExptoFE(int Lfield)
	  {
	    return ExptoFE[Lfield];
	  }

	  /**
	   * Retreve the FEtoExp table for the input Lfield.
	   * 
	   * @param Lfield == the Lfield to retrieve a FEtoExp table for. */
	  public static int[] getFEtoExp(int Lfield) 
	  {
	    return FEtoExp[Lfield];
	  }

	  /**
	   * initField initializes the finite Field Element to Exponent (FEtoExp)
	   *   table and the Exponent to finite Field Element (ExptoFE) table.
	   *
	   * Recall SMultField = TableLength - 1 is the number of 
	   *   elements in the multiplicative group of the field. 
	   * 
	   * @param pCOLBIT == is a pointer to the COLBIT, which is used to 
	   *                   make sure rows and columns have 
	   *                   distinct field elements associated with them.
	   * @param BIT == The BIT array is used to mask out single bits in 
	   *               equations: bit 
	   * @param ExptoFE == ExptoFE is the table that goes from the exponent to the 
	   *                   finite field element. 
	   * @param FEtoExp == FEtoExp is the table that goes from the finite field 
	   *                   element to the exponent.
	   * @param Lfield == Lfield is the log of the length of the field.. */
	  public static void initField(int[] pCOLBIT, int[] BIT, int[] ExptoFE, 
				       int[] FEtoExp, int Lfield)
	  {
	    /** 
	     * Recall SMultField = TableLength - 1 is the number of 
	     *   elements in the multiplicative group of the field. */ 
	    int SMultField = (1 << Lfield) - 1;

	    /**
	     * CARRYMASK is used to see when there is a carry in the polynomial
	     * and when it should be XOR'd with POLYMASK. */
	    int CARRYMASK;
	    
	    /**
	     * POLYMASK is the irreducible polynomial. */
	    int POLYMASK[] = {0x0, 0x3, 0x7, 0xB, 0x13, 0x25, 0x43, 0x83, 
			      0x11D, 0x211, 0x409, 0x805, 0x1053, 0x201B, 
			      0x402B, 0x8003, 0x1100B} ;
	    int i ;
	    
	    BIT[0] = 0x1 ;
	    
	    for(i=1; i < Lfield ; i++) 
	      BIT[i] = BIT[i-1] << 1 ;
	    
	    pCOLBIT[0] = BIT[Lfield-1] ;
	    CARRYMASK = pCOLBIT[0] << 1 ;
	    ExptoFE[0] = 0x1 ;
	    
	    
	    for(i = 1; i < SMultField + Lfield - 1; i++)
	    {
	      ExptoFE[i] = ExptoFE[i-1] << 1;
	      if((ExptoFE[i] & CARRYMASK) > 0) 
		ExptoFE[i] ^= POLYMASK[Lfield] ;
	    }
	      
	    FEtoExp[0] = -1 ;
	    for(i=0; i < SMultField ; i++)	
	      FEtoExp[ExptoFE[i]] = i;
	  }


	  /**
	   * This routine will generate tables for the input number of Lfields
	   * and output them to stdout.
	   *
	   * @param maxLfield == maximum Lfield to produce fields for
	   */
	  public static void generateTables (int maxLfield)
	  {
	    /*  TableLength = 2^Lfield
	     *  COLBIT = new int[2]
	     *  BIT = new int[16]
	     *  ExptoFE = new int[TableLength + Lfield]
	     *  FEtoExp = new int[TableLength]
	     */

	    COLBIT = new int[maxLfield+1][];
	    BIT = new int[maxLfield+1][];
	    ExptoFE = new int[maxLfield+1][];
	    FEtoExp = new int[maxLfield+1][];
		
	    for(int Lfield = 1; Lfield <= maxLfield; ++Lfield) 
	    {
	      int TableLength = 1<<Lfield;
	      COLBIT[Lfield] = new int[1];
	      BIT[Lfield] = new int[16];
	      ExptoFE[Lfield] = new int[TableLength + Lfield];
	      FEtoExp[Lfield] = new int[TableLength];
	      initField(COLBIT[Lfield], BIT[Lfield], ExptoFE[Lfield],
			FEtoExp[Lfield], Lfield);
	    }
	  }

	}
