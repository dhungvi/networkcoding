package ch.epfl.lsr.adhoc.routing.ncode.fast;

public class CauchyEncode {

}
