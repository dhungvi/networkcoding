package ch.epfl.lsr.adhoc.routing.ncode.fast;

import java.util.Hashtable;
import java.util.Vector;

import ch.epfl.lsr.adhoc.runtime.IMessageFactory;
import ch.epfl.lsr.adhoc.runtime.Message;
import ch.epfl.lsr.adhoc.runtime.PoolLimitExceededException;
import ch.epfl.lsr.adhoc.runtime.UnknownMessageTypeException;

public class Globals {
    public static int MaxBufLength= 1000;
    public static int pool=10;    
}

